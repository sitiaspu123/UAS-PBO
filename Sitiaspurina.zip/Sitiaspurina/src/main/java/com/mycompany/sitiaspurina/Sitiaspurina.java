/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sitiaspurina;

/**
 *
 * @author anggu
 */
public class Sitiaspurina {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
